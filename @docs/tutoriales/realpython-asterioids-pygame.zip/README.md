# Build an Asteroids Game With Python and Pygame

The code in this folder supplements the tutorial [Build an Asteroids Game With Python and Pygame](https://realpython.com/asteroids-game-python/).

There are eleven subfolders: one for each of the ten steps in the project and one with the final source code of the full game.
