from game import SpaceRocks


if __name__ == "__main__":
    space_rocks = SpaceRocks()
    space_rocks.main_loop()
