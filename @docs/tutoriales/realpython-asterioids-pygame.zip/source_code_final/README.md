# Space Rocks

A simple space game made with Python and Pygame

## Installation

Requires Python 3.

```
pip install -r requirements.txt
python space_rocks
```
